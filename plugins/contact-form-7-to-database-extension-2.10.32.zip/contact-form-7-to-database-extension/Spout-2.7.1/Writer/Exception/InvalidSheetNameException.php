<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class InvalidSheetNameException
 *
 * @api
 * @package Box\Spout\Writer\Exception
 */
class InvalidSheetNameException extends WriterException
{
}
